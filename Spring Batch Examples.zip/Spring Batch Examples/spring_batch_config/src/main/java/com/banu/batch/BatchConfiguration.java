package com.banu.batch;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.banu.entity.Product;

@Configuration
@EnableBatchProcessing
// @Import(AdditionalBatchConfiguration.class)
public class BatchConfiguration {

	// Input, processor, and output definition

	@Bean
	public ItemReader<Product> reader() {
		FlatFileItemReader<Product> reader = new FlatFileItemReader<Product>();
		reader.setResource(new ClassPathResource("products.txt"));
		reader.setLineMapper(new DefaultLineMapper<Product>() {
			{
				setLineTokenizer(new DelimitedLineTokenizer() {
					{
						setNames(new String[] { "id", "name", "description", "price" });
					}
				});
				setFieldSetMapper(new BeanWrapperFieldSetMapper<Product>() {
					{
						setTargetType(Product.class);
					}
				});

			}
		});
		return reader;
	}

	@Bean
	public ItemProcessor<Product, Product> processor() {
		return new ProductItemProcessor();
	}

	@Bean
	public ItemWriter<Product> writer(DataSource dataSource) {
		final String INSERT_PRODUCT = "insert into product "
				+ "(id,name,description,price) values(:id,:name,:description,:price)";

		JdbcBatchItemWriter<Product> writer = new JdbcBatchItemWriter<Product>();
		writer.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<Product>());
		writer.setSql(INSERT_PRODUCT);
		writer.setDataSource(dataSource);
		return writer;
	}

	// Actual job configuration
	@Bean
	public Job importProductJob(JobBuilderFactory jobs, Step s1) {
//		return jobs.get("importProductJob").incrementer(new RunIdIncrementer()).flow(s1).end().build();
		return jobs.get("importProductJob").start(s1).build();
	}

	@Bean
	public Step step1(StepBuilderFactory stepBuilderFactory, ItemReader<Product> reader, ItemWriter<Product> writer,
			ItemProcessor<Product, Product> processor) {
		return stepBuilderFactory.get("step1").<Product, Product> chunk(10).reader(reader).processor(processor)
				.writer(writer).build();
	}

	@Bean
	public JdbcTemplate jdbcTemplate(DataSource dataSource) {
		return new JdbcTemplate(dataSource);
	}

	@Bean
    public DataSource dataSource() {
       DriverManagerDataSource dataSource = new DriverManagerDataSource();
       	dataSource.setDriverClassName("com.mysql.jdbc.Driver");
       	dataSource.setUrl("jdbc:mysql://localhost:3306/batch_database?createDatabaseIfNotExist=true");
       	dataSource.setUsername("root");
       	dataSource.setPassword("Welcome123");
       return dataSource;
    }
}
