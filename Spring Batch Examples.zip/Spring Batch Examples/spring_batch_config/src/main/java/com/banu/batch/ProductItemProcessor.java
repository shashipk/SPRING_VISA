package com.banu.batch;

import org.springframework.batch.item.ItemProcessor;

import com.banu.entity.Product;

public class ProductItemProcessor implements ItemProcessor<Product, Product> {

	@Override
	public Product process(Product product) throws Exception {
		System.out.println("Before " + product);
		Product p = new Product(product.getId(),product.getName(),product.getDescription(),product.getPrice());
		
		p.setId(p.getId().substring(p.getId().lastIndexOf('.') + 1));
		System.out.println("After " + p);
		return p;
	}

}
