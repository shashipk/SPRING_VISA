package com.banu.client;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import com.banu.batch.ApplicationConfiguration;

@Component
public class MainJobLauncher {

    @Autowired
    JobLauncher jobLauncher;
    @Autowired
    Job importProductJob;

    public static void main(String... args) 
    		throws Exception {

        AnnotationConfigApplicationContext context = 
        		new AnnotationConfigApplicationContext(ApplicationConfiguration.class);

        MainJobLauncher main = context.getBean(MainJobLauncher.class);
        main.jobLauncher.run(main.importProductJob, new JobParameters());
        context.close();
    }
}
