package com.example;

import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

/**
 * Custom Health Check.
 * 
 * @author Banu Prakash
 *
 */
@Component
public class HealthCheck implements HealthIndicator {
    @Override
    public Health health() {
        int errorCode = check(); // perform some specific health check
        if (errorCode != 0) {
            return Health.down()
            		.withDetail("Error Code", errorCode)
            		.withDetail("Description", "custom MyHealthCheck endpoint is down")
            		.build();
        }
        return Health.up().build();
    }
     
    public int check() {
        // Your logic to check health
        return 1;
    }
}