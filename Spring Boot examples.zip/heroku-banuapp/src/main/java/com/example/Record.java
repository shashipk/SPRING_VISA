package com.example;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="records")
public class Record {

    @Id
    private long id;
    @NotEmpty
    @Column(name="record_data")
    private String data;

    public Record() {
	}

    
    public Record(long id, String data) {
		super();
		this.id = id;
		this.data = data;
	}


	public Record(String data) {
		this.data = data;
	}


	public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }


	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}

}