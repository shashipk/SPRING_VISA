package com.example;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.actuate.endpoint.Endpoint;
import org.springframework.stereotype.Component;

/**
 * 
 * @author Banu Prakash
 *
 */
@Component
public class CustomEndpoint implements Endpoint<List<String>> {
	public String getId() {
		return "customEndpoint";
	}

	public boolean isEnabled() {
		return true;
	}

	public boolean isSensitive() {
		return true;
	}

	public List<String> invoke() {
		// Custom logic to build the output
		List<String> messages = new ArrayList<String>();
		messages.add("This is first message");
		messages.add("This is second message");
		return messages;
	}
}
