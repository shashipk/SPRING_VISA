package com.example;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@SpringBootApplication
public class DemoApplication {

	@Autowired
	private RecordRepository repository;

	@RequestMapping("/")
	@ResponseBody
	public String home() {
		return "Hello World!";
	}

	@RequestMapping("/records")
	@ResponseBody
	public List<Record> getRecords() {
		return repository.findAll();
	}

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@Bean
	public CommandLineRunner demo(RecordRepository repository) {
		return (args) -> {
			repository.deleteAll(); // delete
			// save a couple of movies
			repository.save(new Record(1, "First"));
			repository.save(new Record(2, "Second"));
			repository.save(new Record(3, "Third"));
		};
	}
}