package com.banu.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Banu Prakash
 */
@SpringBootApplication
public class SecureApplication {
	public static void main(String[] args) {
		SpringApplication.run(SecureApplication.class, args);
	}
}
