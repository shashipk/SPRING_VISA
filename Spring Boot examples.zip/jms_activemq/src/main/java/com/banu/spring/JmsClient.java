package com.banu.spring;

public interface JmsClient {
	public void send(String msg);
    public String receive();
}
