package com.banu.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JmsActivemqApplication {

	public static void main(String[] args) {
		SpringApplication.run(JmsActivemqApplication.class, args);
	}
}
