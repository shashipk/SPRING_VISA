/**
 * 
 */
package com.banu.spring.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.banu.spring.dao.EmployeeRepository;
import com.banu.spring.model.Employee;

/**
 * @author Banu Prakash
 *
 */
@RestController
@RequestMapping("/employees")
public class EmployeeController {

	@Autowired
	private EmployeeRepository employeeRepository;

	@RequestMapping(method = RequestMethod.POST)
	public Employee create(@RequestBody Employee employee) {
		return employeeRepository.save(employee);
	}

	@RequestMapping(method = RequestMethod.GET)
	public List<Employee> getEmployees() {
		return employeeRepository.findAll();
	}

	@RequestMapping(method = RequestMethod.GET, value = "/{employeeId}")
	public Employee get(@PathVariable String employeeId) {
		return employeeRepository.findOne(employeeId);
	}
}