package com.banu.spring.dao;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.banu.spring.model.Employee;

/**
 * 
 * @author Banu Prakash
 *
 */
public interface EmployeeRepository extends MongoRepository<Employee, String> {

}

